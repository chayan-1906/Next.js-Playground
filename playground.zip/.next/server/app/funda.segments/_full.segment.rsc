1:"$Sreact.fragment"
2:I[79520,["/_next/static/chunks/240461da8f3815e6.js"],""]
8:I[53348,["/_next/static/chunks/2b7d3d1ef81e24c2.js"],"default"]
a:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"default"]
b:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"default"]
c:I[22016,["/_next/static/chunks/240461da8f3815e6.js","/_next/static/chunks/1e8495cae624d565.js"],""]
d:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"OutletBoundary"]
e:"$Sreact.suspense"
10:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"ViewportBoundary"]
12:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"MetadataBoundary"]
14:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"IconMark"]
:HL["/_next/static/chunks/fe4662d9f6ead1f0.css","style"]
:HL["/_next/static/chunks/4ae6e8821d8b1a9e.css","style"]
:HL["/_next/static/media/8dfd6563338cbf38-s.p.000a3bf9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.css","style"]
3:Tb3c,
                if (typeof CookieConsent !== 'undefined') {
                    CookieConsent.run({
                        guiOptions: {
                            consentModal: {
                                layout: 'box',
                                position: 'bottom right'
                            }
                        },
                        categories: {
                            necessary: {
                                enabled: true,
                                readOnly: true
                            },
                            analytics: {
                                enabled: false,
                                readOnly: false
                            }
                        },
                        language: {
                            default: 'en',
                            translations: {
                                en: {
                                    consentModal: {
                                        title: 'We use cookies',
                                        description: 'This is a demo of beforeInteractive strategy. Cookie consent must load before any tracking scripts.',
                                        acceptAllBtn: 'Accept all',
                                        acceptNecessaryBtn: 'Reject all',
                                        showPreferencesBtn: 'Manage preferences'
                                    },
                                    preferencesModal: {
                                        title: 'Cookie preferences',
                                        acceptAllBtn: 'Accept all',
                                        acceptNecessaryBtn: 'Reject all',
                                        savePreferencesBtn: 'Save preferences',
                                        sections: [
                                            {
                                                title: 'Necessary cookies',
                                                description: 'These cookies are essential for the website to function.',
                                                linkedCategory: 'necessary'
                                            },
                                            {
                                                title: 'Analytics cookies',
                                                description: 'These cookies help us understand how visitors use the website.',
                                                linkedCategory: 'analytics'
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    });
                    console.log('[COOKIE CONSENT] Initialized successfully');
                }
            0:{"P":null,"b":"D5tPW-1f4RFn4JbaSmC1J","c":["","funda"],"q":"","i":false,"f":[[["",{"children":["funda",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/fe4662d9f6ead1f0.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/4ae6e8821d8b1a9e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/240461da8f3815e6.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"roboto_serif_ef86fb37-module__mAD7fq__variable antialiased","children":[["$","$L2",null,{"src":"https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.umd.js","strategy":"beforeInteractive","id":"cookie-consent-script"}],["$","link",null,{"rel":"stylesheet","href":"https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.css"}],["$","$L2",null,{"id":"cookie-consent-init","strategy":"afterInteractive","children":"$3"}],"$L4"]}]}]]}],{"children":["$L5",{"children":["$L6",{},null,true,false]},null,true,false]},null,true,false],"$L7",true]],"m":"$undefined","G":["$8",["$L9"]],"S":true}
4:["$","$La",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Lb",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]
5:["$","$1","c",{"children":[null,["$","$La",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Lb",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
6:["$","$1","c",{"children":[["$","div",null,{"className":"max-w-4xl mx-auto flex flex-col p-6 gap-8","children":[["$","div",null,{"children":[["$","h1",null,{"className":"text-3xl font-bold text-gray-900 dark:text-gray-200","children":"Funda"}],["$","p",null,{"className":"mt-1 text-gray-500","children":"Explore linked profile data"}]]}],["$","div",null,{"className":"grid gap-6 sm:grid-cols-2","children":[["$","$Lc",null,{"href":"/funda/people","className":"group rounded-2xl bg-white shadow-md hover:shadow-xl transition-all p-6 border border-gray-100","children":[["$","div",null,{"className":"size-12 rounded-xl bg-indigo-100 flex items-center justify-center mb-4 group-hover:bg-indigo-200 transition-colors","children":["$","span",null,{"className":"text-2xl","children":"👤"}]}],["$","h2",null,{"className":"text-xl font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors","children":"People"}],["$","p",null,{"className":"mt-2 text-gray-500 text-sm","children":"Browse professional profiles with skills, education, and career summaries"}],["$","div",null,{"className":"mt-4 text-indigo-600 text-sm font-medium flex items-center gap-1","children":[["$","span",null,{"children":"View profiles"}],["$","span",null,{"className":"group-hover:translate-x-1 transition-transform","children":"→"}]]}]]}],["$","$Lc",null,{"href":"/funda/companies","className":"group rounded-2xl bg-white shadow-md hover:shadow-xl transition-all p-6 border border-gray-100","children":[["$","div",null,{"className":"size-12 rounded-xl bg-emerald-100 flex items-center justify-center mb-4 group-hover:bg-emerald-200 transition-colors","children":["$","span",null,{"className":"text-2xl","children":"🏢"}]}],["$","h2",null,{"className":"text-xl font-semibold text-gray-900 group-hover:text-emerald-600 transition-colors","children":"Companies"}],["$","p",null,{"className":"mt-2 text-gray-500 text-sm","children":"Discover organizations and their headquarters locations"}],["$","div",null,{"className":"mt-4 text-emerald-600 text-sm font-medium flex items-center gap-1","children":[["$","span",null,{"children":"View companies"}],["$","span",null,{"className":"group-hover:translate-x-1 transition-transform","children":"→"}]]}]]}]]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/1e8495cae624d565.js","async":true,"nonce":"$undefined"}]],["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}]
7:["$","$1","h",{"children":[null,["$","$L10",null,{"children":"$L11"}],["$","div",null,{"hidden":true,"children":["$","$L12",null,{"children":["$","$e",null,{"name":"Next.Metadata","children":"$L13"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
9:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/4ae6e8821d8b1a9e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
f:null
13:[["$","title","0",{"children":"Next.js Playground"}],["$","meta","1",{"name":"description","content":"Generated by create next app"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L14","3",{}]]
