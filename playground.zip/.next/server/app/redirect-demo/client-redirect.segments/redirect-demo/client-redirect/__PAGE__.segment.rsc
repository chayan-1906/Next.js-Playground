1:"$Sreact.fragment"
2:I[47257,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"ClientPageRoot"]
3:I[22303,["/_next/static/chunks/240461da8f3815e6.js","/_next/static/chunks/a118426617a7a7f6.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"OutletBoundary"]
5:"$Sreact.suspense"
0:{"buildId":"D5tPW-1f4RFn4JbaSmC1J","rsc":["$","$1","c",{"children":[["$","$L2",null,{"Component":"$3","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/a118426617a7a7f6.js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"loading":null,"isPartial":false}
6:null
