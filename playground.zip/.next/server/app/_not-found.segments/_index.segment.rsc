1:"$Sreact.fragment"
2:I[79520,["/_next/static/chunks/240461da8f3815e6.js"],""]
5:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"default"]
6:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"default"]
:HL["/_next/static/chunks/fe4662d9f6ead1f0.css","style"]
:HL["/_next/static/chunks/4ae6e8821d8b1a9e.css","style"]
:HL["https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.css","style"]
3:Tb3c,
                if (typeof CookieConsent !== 'undefined') {
                    CookieConsent.run({
                        guiOptions: {
                            consentModal: {
                                layout: 'box',
                                position: 'bottom right'
                            }
                        },
                        categories: {
                            necessary: {
                                enabled: true,
                                readOnly: true
                            },
                            analytics: {
                                enabled: false,
                                readOnly: false
                            }
                        },
                        language: {
                            default: 'en',
                            translations: {
                                en: {
                                    consentModal: {
                                        title: 'We use cookies',
                                        description: 'This is a demo of beforeInteractive strategy. Cookie consent must load before any tracking scripts.',
                                        acceptAllBtn: 'Accept all',
                                        acceptNecessaryBtn: 'Reject all',
                                        showPreferencesBtn: 'Manage preferences'
                                    },
                                    preferencesModal: {
                                        title: 'Cookie preferences',
                                        acceptAllBtn: 'Accept all',
                                        acceptNecessaryBtn: 'Reject all',
                                        savePreferencesBtn: 'Save preferences',
                                        sections: [
                                            {
                                                title: 'Necessary cookies',
                                                description: 'These cookies are essential for the website to function.',
                                                linkedCategory: 'necessary'
                                            },
                                            {
                                                title: 'Analytics cookies',
                                                description: 'These cookies help us understand how visitors use the website.',
                                                linkedCategory: 'analytics'
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    });
                    console.log('[COOKIE CONSENT] Initialized successfully');
                }
            0:{"buildId":"D5tPW-1f4RFn4JbaSmC1J","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/fe4662d9f6ead1f0.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/4ae6e8821d8b1a9e.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/240461da8f3815e6.js","async":true}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"roboto_serif_ef86fb37-module__mAD7fq__variable antialiased","children":[["$","$L2",null,{"src":"https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.umd.js","strategy":"beforeInteractive","id":"cookie-consent-script"}],["$","link",null,{"rel":"stylesheet","href":"https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.css"}],["$","$L2",null,{"id":"cookie-consent-init","strategy":"afterInteractive","children":"$3"}],"$L4"]}]}]]}],"loading":null,"isPartial":false}
4:["$","$L5",null,{"parallelRouterKey":"children","template":["$","$L6",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]
