1:"$Sreact.fragment"
2:"$Sreact.suspense"
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"OutletBoundary"]
0:{"buildId":"D5tPW-1f4RFn4JbaSmC1J","rsc":["$","$1","c",{"children":[["$","$2",null,{"children":"$L3"}],[["$","script","script-0",{"src":"/_next/static/chunks/6231034ce1085ace.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":true}
5:null
