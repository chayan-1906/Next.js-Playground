1:"$Sreact.fragment"
2:I[79520,["/_next/static/chunks/240461da8f3815e6.js"],""]
a:I[53348,["/_next/static/chunks/2b7d3d1ef81e24c2.js"],"default"]
c:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"default"]
d:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"default"]
e:I[49191,["/_next/static/chunks/240461da8f3815e6.js","/_next/static/chunks/53da9c066862f13a.js"],"default"]
10:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"OutletBoundary"]
11:"$Sreact.suspense"
13:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"ViewportBoundary"]
15:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"MetadataBoundary"]
18:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"IconMark"]
:HL["/_next/static/chunks/fe4662d9f6ead1f0.css","style"]
:HL["/_next/static/chunks/4ae6e8821d8b1a9e.css","style"]
:HL["/_next/static/media/8dfd6563338cbf38-s.p.000a3bf9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.css","style"]
3:Tb3c,
                if (typeof CookieConsent !== 'undefined') {
                    CookieConsent.run({
                        guiOptions: {
                            consentModal: {
                                layout: 'box',
                                position: 'bottom right'
                            }
                        },
                        categories: {
                            necessary: {
                                enabled: true,
                                readOnly: true
                            },
                            analytics: {
                                enabled: false,
                                readOnly: false
                            }
                        },
                        language: {
                            default: 'en',
                            translations: {
                                en: {
                                    consentModal: {
                                        title: 'We use cookies',
                                        description: 'This is a demo of beforeInteractive strategy. Cookie consent must load before any tracking scripts.',
                                        acceptAllBtn: 'Accept all',
                                        acceptNecessaryBtn: 'Reject all',
                                        showPreferencesBtn: 'Manage preferences'
                                    },
                                    preferencesModal: {
                                        title: 'Cookie preferences',
                                        acceptAllBtn: 'Accept all',
                                        acceptNecessaryBtn: 'Reject all',
                                        savePreferencesBtn: 'Save preferences',
                                        sections: [
                                            {
                                                title: 'Necessary cookies',
                                                description: 'These cookies are essential for the website to function.',
                                                linkedCategory: 'necessary'
                                            },
                                            {
                                                title: 'Analytics cookies',
                                                description: 'These cookies help us understand how visitors use the website.',
                                                linkedCategory: 'analytics'
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    });
                    console.log('[COOKIE CONSENT] Initialized successfully');
                }
            0:{"P":null,"b":"D5tPW-1f4RFn4JbaSmC1J","c":["","funda","companies","[companyId]"],"q":"","i":false,"f":[[["",{"children":["funda",{"children":["companies",{"children":[["companyId","%%drp:companyId:2660078c4617c8%%","d"],{"children":["__PAGE__",{}]}]}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/fe4662d9f6ead1f0.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/4ae6e8821d8b1a9e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/240461da8f3815e6.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"roboto_serif_ef86fb37-module__mAD7fq__variable antialiased","children":[["$","$L2",null,{"src":"https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.umd.js","strategy":"beforeInteractive","id":"cookie-consent-script"}],["$","link",null,{"rel":"stylesheet","href":"https://cdn.jsdelivr.net/gh/orestbida/cookieconsent@3.0.1/dist/cookieconsent.css"}],["$","$L2",null,{"id":"cookie-consent-init","strategy":"afterInteractive","children":"$3"}],"$L4"]}]}]]}],{"children":["$L5",{"children":["$L6",{"children":["$L7",{"children":["$L8",{},null,true,false]},null,true,false]},null,true,false]},null,true,false]},null,true,false],"$L9",true]],"m":"$undefined","G":["$a",["$Lb"]],"S":true}
4:["$","$Lc",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Ld",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]
5:["$","$1","c",{"children":[null,["$","$Lc",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Ld",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
6:["$","$1","c",{"children":[null,["$","$Lc",null,{"parallelRouterKey":"children","error":"$e","errorStyles":[],"errorScripts":[["$","script","script-0",{"src":"/_next/static/chunks/53da9c066862f13a.js","async":true}]],"template":["$","$Ld",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
7:["$","$1","c",{"children":[null,["$","$Lc",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Ld",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
8:["$","$1","c",{"children":["$Lf",[["$","script","script-0",{"src":"/_next/static/chunks/7d94b7de9c861440.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/21e4200ae1e7c339.js","async":true,"nonce":"$undefined"}]],["$","$L10",null,{"children":["$","$11",null,{"name":"Next.MetadataOutlet","children":"$@12"}]}]]}]
9:["$","$1","h",{"children":[null,["$","$L13",null,{"children":"$L14"}],["$","div",null,{"hidden":true,"children":["$","$L15",null,{"children":["$","$11",null,{"name":"Next.Metadata","children":"$L16"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
b:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/4ae6e8821d8b1a9e.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
f:["$","$11",null,{"fallback":["$","div",null,{"className":"flex flex-col max-w-5xl mx-auto p-6 gap-6 animate-pulse","children":[["$","div",null,{"className":"h-5 w-32 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-48 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"rounded-2xl bg-white dark:bg-gray-800 shadow-md dark:shadow-gray-900/50 p-8","children":["$","div",null,{"className":"flex items-start gap-6 mb-6","children":[["$","div",null,{"className":"size-[120px] rounded-lg bg-gray-200 dark:bg-gray-700 shrink-0"}],["$","div",null,{"className":"flex-1 space-y-3","children":[["$","div",null,{"className":"h-8 w-64 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-56 bg-gray-200 dark:bg-gray-700 rounded"}]]}]]}]}],["$","div",null,{"className":"rounded-2xl bg-white dark:bg-gray-800 shadow-md dark:shadow-gray-900/50 p-8","children":[["$","div",null,{"className":"h-6 w-24 bg-gray-200 dark:bg-gray-700 rounded mb-6"}],["$","div",null,{"className":"space-y-6","children":[["$","div","1",{"className":"flex items-start gap-4","children":[["$","div",null,{"className":"size-14 rounded-full bg-gray-200 dark:bg-gray-700 shrink-0"}],["$","div",null,{"className":"flex-1 space-y-2","children":[["$","div",null,{"className":"h-5 w-48 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-64 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-32 bg-gray-200 dark:bg-gray-700 rounded"}]]}]]}],["$","div","2",{"className":"flex items-start gap-4","children":[["$","div",null,{"className":"size-14 rounded-full bg-gray-200 dark:bg-gray-700 shrink-0"}],["$","div",null,{"className":"flex-1 space-y-2","children":[["$","div",null,{"className":"h-5 w-48 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-64 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-32 bg-gray-200 dark:bg-gray-700 rounded"}]]}]]}],["$","div","3",{"className":"flex items-start gap-4","children":[["$","div",null,{"className":"size-14 rounded-full bg-gray-200 dark:bg-gray-700 shrink-0"}],["$","div",null,{"className":"flex-1 space-y-2","children":[["$","div",null,{"className":"h-5 w-48 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-64 bg-gray-200 dark:bg-gray-700 rounded"}],["$","div",null,{"className":"h-4 w-32 bg-gray-200 dark:bg-gray-700 rounded"}]]}]]}]]}]]}]]}],"children":"$L17"}]
14:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
12:null
16:[["$","title","0",{"children":"Next.js Playground"}],["$","meta","1",{"name":"description","content":"Generated by create next app"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L18","3",{}]]
