1:"$Sreact.fragment"
2:I[92881,["/_next/static/chunks/240461da8f3815e6.js","/_next/static/chunks/fa87f0fc427ec340.js"],"TabSwitcher"]
3:I[29736,["/_next/static/chunks/240461da8f3815e6.js","/_next/static/chunks/fa87f0fc427ec340.js"],"WithoutTransition"]
4:I[63879,["/_next/static/chunks/240461da8f3815e6.js","/_next/static/chunks/fa87f0fc427ec340.js"],"WithTransition"]
5:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/6af6f5d809ae5e33.js"],"OutletBoundary"]
6:"$Sreact.suspense"
0:{"buildId":"D5tPW-1f4RFn4JbaSmC1J","rsc":["$","$1","c",{"children":[["$","div",null,{"className":"px-4","children":[["$","h1",null,{"className":"text-emerald-300 text-2xl font-bold my-4 text-center","children":"Transitions Demo"}],["$","$L2",null,{}],["$","div",null,{"className":"flex gap-8 h-1/2 overflow-hidden","children":[["$","$L3",null,{}],["$","div",null,{"className":"w-0.5 bg-yellow-300 self-stretch"}],["$","$L4",null,{}]]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/fa87f0fc427ec340.js","async":true}]],["$","$L5",null,{"children":["$","$6",null,{"name":"Next.MetadataOutlet","children":"$@7"}]}]]}],"loading":null,"isPartial":false}
7:null
