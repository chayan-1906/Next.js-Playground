globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/36332d3b395dd0f4.js",
    "static/chunks/5d75a022f81b9365.js",
    "static/chunks/249261e921aeebba.js",
    "static/chunks/d49106d007e3bd3d.js",
    "static/chunks/bc2b362b6c46e63b.js",
    "static/chunks/turbopack-a706ef2ce11ec41e.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];