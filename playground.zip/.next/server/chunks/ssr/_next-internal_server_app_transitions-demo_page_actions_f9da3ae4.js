module.exports=[59164,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_transitions-demo_page_actions_f9da3ae4.js.map