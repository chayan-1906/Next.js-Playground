module.exports=[31644,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_funda_page_actions_7a9b1e0b.js.map