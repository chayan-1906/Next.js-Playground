module.exports=[67862,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_script-demo_page_actions_bd0e48ff.js.map