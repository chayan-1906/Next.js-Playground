module.exports=[5105,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_redirect-demo_server-redirect_page_actions_3c9ec638.js.map