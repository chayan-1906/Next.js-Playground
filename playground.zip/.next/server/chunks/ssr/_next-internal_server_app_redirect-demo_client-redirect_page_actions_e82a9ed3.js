module.exports=[92371,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_redirect-demo_client-redirect_page_actions_e82a9ed3.js.map